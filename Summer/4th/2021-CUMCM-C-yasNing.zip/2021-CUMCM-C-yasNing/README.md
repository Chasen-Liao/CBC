# 2021-CUMCM-C-CODE & FILE

This is the code and source file for Problem 1-4 of Problem C of the 2021 Mathematical Modeling National Competition.

🌐 First, you need to download all the files in this project.Decompress the rar file from the download file,as shown below.

![F@G}NY%A2H2J@`X~($53@QT](https://user-images.githubusercontent.com/93892617/236658787-3a28d34d-fe91-4690-baa1-bef3819512ad.png)


💎 Then, you can do any of the functions described in the blog through the code inside.


Finally, if you find this work useful or interesting, please kindly give us a star ⭐, thanks!😀

